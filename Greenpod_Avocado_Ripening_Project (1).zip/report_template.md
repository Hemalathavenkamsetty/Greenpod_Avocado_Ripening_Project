# Avocado Ripening Stage Classification — Assignment Report

## 1. Objective
Build a computer-vision pipeline to classify avocado ripening stages and compare at least two approaches.

## 2. Dataset description
- Dataset source: assignment Google Drive link.
- Number of images: [fill from `reports/audit_summary.json`]
- Classes and counts: [fill from `reports/class_counts.csv`]
- Train/validation/test split: 70% / 15% / 15% (stratified by class folder, approximate for very small classes).
- Image dimensions and formats: [fill from audit output]

## 3. Data quality, outliers, imbalance, and bias
Describe unreadable files, duplicate images, extreme dimensions, class-count imbalance, backgrounds/lighting, camera differences, and whether images are representative of expected production use. Include actual audit numbers.

## 4. Approach 1 — Classical computer vision
HSV color histogram + HOG texture features + SVM with class balancing. This is a lightweight baseline and can work when ripeness is reflected in color/texture. It may fail under lighting/background variation.

## 5. Approach 2 — MobileNetV2 transfer learning
A pretrained MobileNetV2 feature extractor with a new classification head. Augmentation is used during training. Transfer learning is chosen to reuse general visual features when the dataset is not large enough to train a CNN from scratch.

## 6. Evaluation
Insert values from `reports/classical_metrics.json`, `reports/cnn_metrics.json`, and `reports/model_comparison.csv`.
Discuss accuracy, macro F1, per-class precision/recall, confusion matrices, and inference time. Macro F1 is important when class counts differ. Recall matters when missing a ripeness class has operational cost.

## 7. Results and model selection
Do not fill in guessed scores. Select the best model only after running both approaches on the same held-out test set. Discuss misclassified examples and whether the difference is meaningful.

## 8. Example run
Command: `python src/predict.py --image path\\to\\example.jpg --model cnn`
- Actual predicted class: [paste terminal output]
- Confidence estimate: [paste terminal output]
- Correct/incorrect compared with known label: [verify manually]

## 9. Production performance
A local test score does not guarantee production performance. Real performance depends on lighting, camera, image quality, unseen avocado varieties, background, device hardware, and changes in the data. Validate on images collected in the real operating environment and monitor errors.

## 10. Drawbacks
Discuss limited dataset size, possible label noise, class imbalance, visual overlap between ripeness stages, lighting/background sensitivity, and the fact that this image classifier does not detect multiple objects in a scene.

## 11. Improvements with more time
Collect more diverse labeled images; use group-aware splits to avoid near-duplicate leakage; tune hyperparameters; test fine-tuning; calibrate confidence; measure latency on target hardware; add an abstain/uncertain result; and monitor drift.

## 12. Where most time was spent
Write honestly based on your own work, e.g. dataset download/inspection, cleaning and label verification, training/debugging, or evaluation and analysis. Replace this example with your real experience.

## 13. Conclusion
Summarize the observed test results and justify the selected approach using measured metrics and limitations.
