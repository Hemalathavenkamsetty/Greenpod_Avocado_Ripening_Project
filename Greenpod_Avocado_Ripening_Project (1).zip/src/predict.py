import argparse, json
from pathlib import Path
import numpy as np
from PIL import Image

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", required=True)
    ap.add_argument("--model", choices=["classical", "cnn"], required=True)
    args = ap.parse_args()
    img = Path(args.image)
    if not img.exists():
        raise SystemExit(f"Image not found: {img.resolve()}")
    if args.model == "classical":
        import joblib
        from features import extract_features
        model = joblib.load("models/classical_svm.joblib")
        labels = json.loads(Path("models/classical_labels.json").read_text(encoding="utf-8"))
        x = extract_features(img).reshape(1, -1)
        probs = model.predict_proba(x)[0]
        idx = int(np.argmax(probs))
        print(f"Predicted stage: {model.classes_[idx]}")
        print(f"Model confidence estimate: {probs[idx]*100:.2f}%")
    else:
        import tensorflow as tf
        labels = json.loads(Path("models/cnn_labels.json").read_text(encoding="utf-8"))
        model = tf.keras.models.load_model("models/mobilenetv2_final.keras")
        image = Image.open(img).convert("RGB").resize((224, 224))
        x = np.asarray(image, dtype=np.float32)[None, ...]
        probs = model.predict(x, verbose=0)[0]
        idx = int(np.argmax(probs))
        print(f"Predicted stage: {labels[idx]}")
        print(f"Model confidence estimate: {probs[idx]*100:.2f}%")
    print("Note: confidence is a model score, not a guarantee of correctness.")

if __name__ == "__main__":
    main()
