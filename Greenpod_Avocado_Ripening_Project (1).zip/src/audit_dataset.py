import argparse, json, hashlib
from pathlib import Path
from collections import Counter
from PIL import Image
import pandas as pd

EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="data/raw")
    args = p.parse_args()
    root = Path(args.data)
    if not root.exists():
        raise SystemExit(f"Dataset folder not found: {root.resolve()}")
    classes = sorted(x for x in root.iterdir() if x.is_dir() and not x.name.startswith("."))
    if not classes:
        raise SystemExit("No class subfolders found. Expected data/raw/<class_name>/<image files>.")
    rows, hashes, bad = [], {}, []
    for folder in classes:
        for f in folder.rglob("*"):
            if f.suffix.lower() not in EXTS:
                continue
            digest = hashlib.sha256(f.read_bytes()).hexdigest()
            duplicate_of = hashes.get(digest)
            hashes.setdefault(digest, str(f))
            try:
                with Image.open(f) as im:
                    w, h = im.size
                    im.verify()
                rows.append({"path": str(f), "class": folder.name, "width": w, "height": h,
                             "bytes": f.stat().st_size, "duplicate_of": duplicate_of or ""})
            except Exception as e:
                bad.append({"path": str(f), "error": str(e)})
    out = Path("reports"); out.mkdir(exist_ok=True)
    df = pd.DataFrame(rows)
    df.to_csv(out / "image_inventory.csv", index=False)
    if not df.empty:
        counts = df.groupby("class").size().rename("image_count").reset_index()
        counts.to_csv(out / "class_counts.csv", index=False)
        dup_count = int((df["duplicate_of"] != "").sum())
        summary = {
            "dataset_path": str(root.resolve()), "valid_images": int(len(df)),
            "class_count": int(df["class"].nunique()),
            "class_counts": {str(k): int(v) for k, v in df["class"].value_counts().items()},
            "duplicate_files_after_first_copy": dup_count,
            "unreadable_images": len(bad),
            "image_width_min": int(df["width"].min()), "image_width_max": int(df["width"].max()),
            "image_height_min": int(df["height"].min()), "image_height_max": int(df["height"].max()),
            "imbalance_ratio_max_to_min": float(df["class"].value_counts().max() / df["class"].value_counts().min())
        }
    else:
        summary = {"valid_images": 0, "unreadable_images": len(bad)}
    (out / "audit_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    (out / "unreadable_images.json").write_text(json.dumps(bad, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    print(f"\nReports saved to: {out.resolve()}")

if __name__ == "__main__":
    main()
