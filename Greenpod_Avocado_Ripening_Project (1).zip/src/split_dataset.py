import argparse, random, shutil
from pathlib import Path
from collections import defaultdict

EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input", default="data/raw")
    p.add_argument("--output", default="data/split")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--train", type=float, default=.70)
    p.add_argument("--val", type=float, default=.15)
    args = p.parse_args()
    if args.train <= 0 or args.val <= 0 or args.train + args.val >= 1:
        raise SystemExit("train and val must be positive and sum to less than 1.")
    src, dst = Path(args.input), Path(args.output)
    classes = sorted(x for x in src.iterdir() if x.is_dir() and not x.name.startswith(".")) if src.exists() else []
    if not classes:
        raise SystemExit(f"No class folders found in {src.resolve()}")
    rng = random.Random(args.seed)
    for c in classes:
        images = [f for f in c.rglob("*") if f.suffix.lower() in EXTS]
        rng.shuffle(images)
        n = len(images)
        if n < 3:
            raise SystemExit(f"Class '{c.name}' has only {n} image(s); need at least 3 for train/val/test.")
        n_train = max(1, int(n * args.train))
        n_val = max(1, int(n * args.val))
        if n_train + n_val >= n:
            n_train, n_val = n - 2, 1
        groups = {"train": images[:n_train], "val": images[n_train:n_train+n_val], "test": images[n_train+n_val:]}
        for split, paths in groups.items():
            target = dst / split / c.name
            target.mkdir(parents=True, exist_ok=True)
            for i, f in enumerate(paths):
                # unique names avoid collisions from nested source folders
                name = f"{i:05d}_{f.name}"
                shutil.copy2(f, target / name)
        print(f"{c.name}: " + ", ".join(f"{k}={len(v)}" for k, v in groups.items()))
    print(f"Split complete: {dst.resolve()}")

if __name__ == "__main__":
    main()
