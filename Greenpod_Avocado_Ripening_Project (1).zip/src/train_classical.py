import argparse, json
from pathlib import Path
import joblib, numpy as np, pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score
from features import extract_features

EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}

def collect(root):
    X, y = [], []
    root = Path(root)
    for cls in sorted(p for p in root.iterdir() if p.is_dir()):
        for f in cls.rglob("*"):
            if f.suffix.lower() in EXTS:
                try:
                    X.append(extract_features(f)); y.append(cls.name)
                except Exception as e:
                    print(f"Skipping {f}: {e}")
    return np.asarray(X), np.asarray(y)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/split")
    args = ap.parse_args()
    reports, models = Path("reports"), Path("models")
    reports.mkdir(exist_ok=True); models.mkdir(exist_ok=True)
    Xtr, ytr = collect(Path(args.data) / "train")
    Xv, yv = collect(Path(args.data) / "val")
    Xt, yt = collect(Path(args.data) / "test")
    if len(Xtr) == 0 or len(Xt) == 0:
        raise SystemExit("No images found. Run audit and split steps first.")
    model = make_pipeline(StandardScaler(), SVC(kernel="rbf", class_weight="balanced", probability=True, random_state=42))
    model.fit(Xtr, ytr)
    pred = model.predict(Xt)
    labels = sorted(set(ytr) | set(yt))
    metrics = {"model": "classical_svm", "accuracy": float(accuracy_score(yt, pred)),
               "macro_f1": float(f1_score(yt, pred, average="macro", zero_division=0)),
               "classification_report": classification_report(yt, pred, labels=labels, output_dict=True, zero_division=0),
               "confusion_matrix": confusion_matrix(yt, pred, labels=labels).tolist(), "labels": labels}
    joblib.dump(model, models / "classical_svm.joblib")
    (models / "classical_labels.json").write_text(json.dumps(labels, indent=2), encoding="utf-8")
    (reports / "classical_metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(json.dumps({"accuracy": metrics["accuracy"], "macro_f1": metrics["macro_f1"], "labels": labels}, indent=2))

if __name__ == "__main__":
    main()
