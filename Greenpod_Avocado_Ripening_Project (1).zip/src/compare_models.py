import json
from pathlib import Path
import pandas as pd

def main():
    rows = []
    for name, file in [("Classical SVM", "reports/classical_metrics.json"),
                       ("MobileNetV2", "reports/cnn_metrics.json")]:
        p = Path(file)
        if p.exists():
            d = json.loads(p.read_text(encoding="utf-8"))
            rows.append({"model": name, "accuracy": d.get("accuracy"), "macro_f1": d.get("macro_f1")})
        else:
            print(f"Not found yet: {file}")
    if not rows:
        raise SystemExit("Train both models first.")
    df = pd.DataFrame(rows).sort_values("macro_f1", ascending=False)
    Path("reports").mkdir(exist_ok=True)
    df.to_csv("reports/model_comparison.csv", index=False)
    print(df.to_string(index=False))
    print("\nUse macro F1 plus per-class recall and confusion matrices to choose a model; do not choose by accuracy alone.")
if __name__ == "__main__":
    main()
