import argparse, json
from pathlib import Path
import tensorflow as tf
import numpy as np
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score

IMG_SIZE = (224, 224)
BATCH = 16

def dataset(path, shuffle):
    return tf.keras.utils.image_dataset_from_directory(
        path, image_size=IMG_SIZE, batch_size=BATCH, label_mode="int",
        shuffle=shuffle, seed=42)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/split")
    ap.add_argument("--epochs", type=int, default=8)
    args = ap.parse_args()
    base = Path(args.data)
    train_ds = dataset(base / "train", True)
    class_names = train_ds.class_names
    val_ds = dataset(base / "val", False)
    test_ds = dataset(base / "test", False)
    if len(class_names) < 2:
        raise SystemExit("At least two class folders are required.")
    autotune = tf.data.AUTOTUNE
    train_ds = train_ds.prefetch(autotune)
    val_ds = val_ds.prefetch(autotune)
    test_ds = test_ds.prefetch(autotune)
    aug = tf.keras.Sequential([
        tf.keras.layers.RandomFlip("horizontal"),
        tf.keras.layers.RandomRotation(0.08),
        tf.keras.layers.RandomZoom(0.10),
    ])
    backbone = tf.keras.applications.MobileNetV2(
        input_shape=(*IMG_SIZE, 3), include_top=False, weights="imagenet")
    backbone.trainable = False
    inputs = tf.keras.Input(shape=(*IMG_SIZE, 3))
    x = aug(inputs)
    x = tf.keras.applications.mobilenet_v2.preprocess_input(x)
    x = backbone(x, training=False)
    x = tf.keras.layers.GlobalAveragePooling2D()(x)
    x = tf.keras.layers.Dropout(0.25)(x)
    outputs = tf.keras.layers.Dense(len(class_names), activation="softmax")(x)
    model = tf.keras.Model(inputs, outputs)
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-3),
                  loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    callbacks = [
        tf.keras.callbacks.EarlyStopping(monitor="val_loss", patience=3, restore_best_weights=True),
        tf.keras.callbacks.ModelCheckpoint("models/mobilenetv2_best.keras", monitor="val_loss", save_best_only=True)
    ]
    Path("models").mkdir(exist_ok=True); Path("reports").mkdir(exist_ok=True)
    model.fit(train_ds, validation_data=val_ds, epochs=args.epochs, callbacks=callbacks)
    y_true = np.concatenate([y.numpy() for _, y in test_ds])
    probs = model.predict(test_ds, verbose=0)
    y_pred = probs.argmax(axis=1)
    labels_idx = list(range(len(class_names)))
    metrics = {"model": "mobilenetv2_transfer_learning",
               "accuracy": float(accuracy_score(y_true, y_pred)),
               "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
               "classification_report": classification_report(y_true, y_pred, labels=labels_idx,
                    target_names=class_names, output_dict=True, zero_division=0),
               "confusion_matrix": confusion_matrix(y_true, y_pred, labels=labels_idx).tolist(),
               "labels": class_names}
    model.save("models/mobilenetv2_final.keras")
    (Path("models") / "cnn_labels.json").write_text(json.dumps(class_names, indent=2), encoding="utf-8")
    (Path("reports") / "cnn_metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(json.dumps({"accuracy": metrics["accuracy"], "macro_f1": metrics["macro_f1"], "labels": class_names}, indent=2))

if __name__ == "__main__":
    main()
